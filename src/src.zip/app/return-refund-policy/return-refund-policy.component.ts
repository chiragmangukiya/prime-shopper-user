import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-return-refund-policy',
  templateUrl: './return-refund-policy.component.html',
  styleUrls: ['./return-refund-policy.component.css']
})
export class ReturnRefundPolicyComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
