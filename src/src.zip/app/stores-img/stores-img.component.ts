import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-stores-img',
  templateUrl: './stores-img.component.html',
  styleUrls: ['./stores-img.component.css']
})
export class StoresImgComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
